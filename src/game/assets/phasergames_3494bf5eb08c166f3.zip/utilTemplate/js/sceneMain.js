class SceneMain extends Phaser.Scene {
    constructor() {
        super('SceneMain');
    }
    preload()
    {
    	
    }
    create() {
        console.log("Ready!");
    }
    update() {}
}